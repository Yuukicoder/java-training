package BubbleSort;

/**
 * PositiveNumberException
 */
public class PositiveNumberException extends Exception {
    public PositiveNumberException(String msg) {
        super(msg);
    }
}