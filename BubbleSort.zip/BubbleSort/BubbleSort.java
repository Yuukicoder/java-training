package BubbleSort;

import java.util.Random;
import java.util.Scanner;

public class BubbleSort {

    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // 1. Display the screen
        // 2. Check user input
        // 3. Users input size of array
        // 4. Generate random integer in number range
        // 5. unsorted array
        // 6. sorted array
        int n = sizeOfArray();
        int a[] = randomArray(n);
        unsortArray(a);
        int b[] = BubbleSortArray(a);
        afterSort(b);
    }

    // Check input
    public static int inputPositiveNumber() {
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine().trim());
                if (result <= 0) {
                    throw new PositiveNumberException("Please input positive number!");
                }
                return result;
            } catch (PositiveNumberException e1) {
                System.out.println(e1.getMessage());
                continue;
            } catch (NumberFormatException e) {
                // TODO: handle exception
                System.out.println("Please input number! Try again!!");
                continue;
            }
        }
    }

    // input size of array
    public static int sizeOfArray() {
        System.out.println("Enter number of array");
        int n = inputPositiveNumber();
        return n;
    }

    // random array
    public static int[] randomArray(int num) {
        int[] a = new int[num];
        for (int i = 0; i < num; i++) {
            a[i] = new Random().nextInt(num);
        }
        return a;
    }

    // display unsorted array
    public static void unsortArray(int[] a) {
        System.out.println("Unsorted Array:");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }

    // Bubblesort
    public static int[] BubbleSortArray(int[] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a.length; j++) {
                if (a[i] < a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        System.out.println(" ");
        return a;
    }

    // display sorted array
    public static void afterSort(int[] a) {
        System.out.println("Sorted array: ");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}
